#!/sbin/busybox sh
if [ ! -f /data/.prestigemod/efsbackup.tar.gz ];
then
  mkdir /data/.prestigemod
  chmod 777 /data/.prestigemod
  /sbin/busybox tar zcvf /data/.prestigemod/efsbackup.tar.gz /efs
  /sbin/busybox cat /dev/block/mmcblk0p3 > /data/.prestigemod/efsdev-mmcblk0p3.img
  /sbin/busybox gzip /data/.prestigemod/efsdev-mmcblk0p3.img
  /sbin/busybox cp /data/.prestigemod/efs* /data/media
  chmod 777 /data/media/efsdev-mmcblk0p3.img
  chmod 777 /data/media/efsbackup.tar.gz
fi

